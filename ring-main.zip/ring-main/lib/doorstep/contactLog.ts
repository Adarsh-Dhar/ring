/**
 * Contact logging infrastructure (Section 7.2).
 *
 * Wraps push and SMS with detailed logging and failure tracking.
 * Updates HelperRequest.channels with delivery results.
 * Marks request as delivered when at least one channel succeeds.
 */
import { pushToMembership, sendSms, type PushPayload } from '@/lib/doorbell/notify'
import { getPushSubscriptionsForMembership } from '@/lib/db/push'
import { getMembership } from '@/lib/db/memberships'
import { getDb } from '@/lib/db/client'
import { updateChannels, markDelivered, type HelperRequest } from './helperRequests'
import { writeAudit, audit } from './audit'

export interface ContactResult {
  push: { sent: number; failed: number; noSubscription: boolean }
  sms: { ok: boolean; reason?: string }
}

/**
 * Contact a helper via push and SMS, logging results and updating the HelperRequest.
 */
export async function contactHelper(
  caseId: string,
  membershipId: string,
  payload: { push: PushPayload; sms: string },
  requestId?: string
): Promise<ContactResult> {
  const membership = await getMembership(membershipId)
  if (!membership) {
    return { push: { sent: 0, failed: 0, noSubscription: true }, sms: { ok: false, reason: 'membership not found' } }
  }

  let user: { name: string | null; phone: string | null } | null = null
  try {
    const db = getDb()
    if (db?.user?.findUnique) {
      user = await db.user.findUnique({
        where: { id: membership.userId },
        select: { name: true, phone: true },
      })
    }
  } catch {
    // Database not available in test mocks
  }

  const userName = user?.name || 'Helper'

  // Push
  const subs = await getPushSubscriptionsForMembership(membershipId)
  let pushSent = 0
  let pushFailed = 0
  let noSubscription = false

  if (subs.length === 0) {
    noSubscription = true
    await writeAudit(caseId, audit.contactAttempt('push', membershipId, 'failed', 'no subscription'))
  } else {
    try {
      const r = await pushToMembership(membershipId, payload.push)
      pushSent = r.sent
      pushFailed = r.failed
      await writeAudit(caseId, audit.contactAttempt('push', membershipId, r.sent > 0 ? 'sent' : 'failed',
        r.sent > 0 ? `${r.sent} accepted, ${r.failed} failed` : `all ${r.failed} attempts failed`))
    } catch (e) {
      pushFailed = subs.length
      await writeAudit(caseId, audit.contactAttempt('push', membershipId, 'failed', (e as Error).message))
    }
  }

  // SMS
  let smsOk = false
  let smsReason: string | undefined

  if (user?.phone) {
    smsOk = await sendSms(user.phone, payload.sms)
    if (smsOk) {
      await writeAudit(caseId, audit.contactAttempt('sms', membershipId, 'sent'))
    } else {
      smsReason = 'delivery failed'
      await writeAudit(caseId, audit.contactAttempt('sms', membershipId, 'failed', smsReason))
    }
  } else {
    smsReason = 'no phone number'
    await writeAudit(caseId, audit.contactAttempt('sms', membershipId, 'failed', smsReason))
  }

  // Update HelperRequest channels if requestId provided
  if (requestId) {
    await updateChannels(requestId, {
      push: { sent: pushSent, failed: pushFailed, noSubscription },
      sms: { ok: smsOk, reason: smsReason },
    })

    // Mark as delivered if at least one channel succeeded
    if (pushSent > 0 || smsOk) {
      await markDelivered(requestId)
    }
  }

  return {
    push: { sent: pushSent, failed: pushFailed, noSubscription },
    sms: { ok: smsOk, reason: smsReason },
  }
}
