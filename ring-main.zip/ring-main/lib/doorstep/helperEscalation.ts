/**
 * Helper escalation (spec section 2). The tested step engine stays in lib/doorbell/escalation.ts:
 * exactly-once claims, next helper, no-response. This module is the stable doorstep-facing entry point and adds
 * the one thing the spec asks for: timers that come from the control mode instead of one fixed number.
 *
 * Silence is never consent: a helper who does not answer ends in `no_response`, which tells the resident to keep
 * the door closed. It is a separate operational problem with its own path, not an approval.
 */
export { escalateDueCase, mergeSaved } from '../doorbell/escalation'
export type { EscalationDeps, EscalationConfig, EscalationKind, StepChange, StepExpect } from '../doorbell/escalation'

import { activeTimer, effectiveScore, riskDecisionNeeded, timersFor } from './collaborationController'
import type { ControlMode } from './riskRules'
import type { TimerDeadlineMap } from './deadline'

/** Return ALL applicable timer durations (not just the governing one) for a fresh helper. */
export function timerDurationsFor(
  score: number | null | undefined,
  minMode: ControlMode | null | undefined,
  householdSec: number,
  needsApproval: boolean = false,
  approvalSec?: number,
): TimerDeadlineMap {
  const result: TimerDeadlineMap = {}
  const eff = effectiveScore(score ?? 0, minMode)
  const timers = timersFor(eff, minMode, approvalSec)

  if (needsApproval && timers.approvalSec !== null) {
    result.approval = timers.approvalSec
  }
  if (timers.riskDecisionSec !== null && riskDecisionNeeded(eff)) {
    result.risk_decision = timers.riskDecisionSec
  }
  if (timers.takeoverSec !== null) {
    result.takeover = timers.takeoverSec
  }

  // If no specific timers, use household as fallback
  if (Object.keys(result).length === 0) {
    result.household = householdSec
  }

  return result
}

/** Seconds the NEXT helper gets (spec 5.3): the risk/takeover timer for S_eff. Returns both seconds and the timer kind. */
export function backupTimeoutSec(
  score: number | null | undefined,
  minMode: ControlMode | null | undefined,
  householdSec: number,
  needsApproval: boolean = false,
  /** The resident's approval timer. Without it the backup would always get the 120 s default. */
  approvalSec?: number,
): { seconds: number; kind: string } {
  if (score == null && !minMode) return { seconds: householdSec, kind: 'household' }
  const eff = effectiveScore(score ?? 0, minMode)
  const t = activeTimer(timersFor(eff, minMode, approvalSec), { needsApproval, riskDecisionNeeded: riskDecisionNeeded(eff) })
  if (t && t.seconds !== null) return { seconds: t.seconds, kind: t.kind }
  return { seconds: householdSec, kind: 'household' }
}
