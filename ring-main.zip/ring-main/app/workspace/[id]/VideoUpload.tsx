'use client'

import { useState, useRef, useEffect } from 'react'

interface VideoUploadProps {
  device: string
  onUploadComplete?: () => void
}

interface UploadedClip {
  device: string
  size: number
  mtime: number
}

const ALLOWED_MIME_TYPES = ['video/mp4']

export default function VideoUpload({ device, onUploadComplete }: VideoUploadProps) {
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null) // Track for cleanup
  const [uploading, setUploading] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [duration, setDuration] = useState<number | null>(null)
  const [uploadedClip, setUploadedClip] = useState<UploadedClip | null>(null)
  const [loadingClip, setLoadingClip] = useState(true)
  const videoRef = useRef<HTMLVideoElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const MAX_SIZE_MB = 50
  const MAX_DURATION_SEC = 30

  // Load existing clip on mount
  useEffect(() => {
    loadExistingClip()
    return () => {
      // Cleanup preview URL on unmount
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl)
      }
    }
  }, [device])

  const loadExistingClip = async () => {
    setLoadingClip(true)
    setUploadedClip(null) // Clear previous device's clip
    try {
      const response = await fetch('/api/sim/videos')
      if (response.ok) {
        const data = await response.json()
        const clip = data.videos?.find((v: UploadedClip) => v.device === device)
        setUploadedClip(clip || null)
      }
    } catch (e) {
      console.error('Failed to load existing clips:', e)
    } finally {
      setLoadingClip(false)
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0]
    if (!selected) return

    setError(null)
    setUploadStatus(null)

    // Validate file type explicitly
    if (!ALLOWED_MIME_TYPES.includes(selected.type)) {
      setError('Please select an MP4 video file')
      // Cleanup if file is rejected
      if (fileInputRef.current) fileInputRef.current.value = ''
      return
    }

    // Check file size
    const sizeMB = selected.size / (1024 * 1024)
    if (sizeMB > MAX_SIZE_MB) {
      setError(`File too large. Maximum ${MAX_SIZE_MB} MB.`)
      // Cleanup if file is rejected
      if (fileInputRef.current) fileInputRef.current.value = ''
      return
    }

    setFile(selected)

    // Create preview URL and track it for cleanup
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl)
    }
    const url = URL.createObjectURL(selected)
    setPreviewUrl(url)
    setPreview(url)

    // Check duration
    const video = document.createElement('video')
    video.preload = 'metadata'
    
    const handleMetadata = () => {
      if (video.duration === 0 || !isFinite(video.duration)) {
        setError('Invalid video duration')
        setFile(null)
        setPreview(null)
        if (previewUrl) {
          URL.revokeObjectURL(previewUrl)
          setPreviewUrl(null)
        }
        const input = fileInputRef.current
        if (input) input.value = ''
        return
      }
      
      if (video.duration > MAX_DURATION_SEC) {
        setError(`Video too long. Maximum ${MAX_DURATION_SEC} seconds.`)
        setFile(null)
        setPreview(null)
        if (previewUrl) {
          URL.revokeObjectURL(previewUrl)
          setPreviewUrl(null)
        }
        const input = fileInputRef.current
        if (input) input.value = ''
      } else {
        setDuration(video.duration)
      }
    }

    const handleError = () => {
      setError('Could not load video metadata')
      setFile(null)
      setPreview(null)
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl)
        setPreviewUrl(null)
      }
        if (fileInputRef.current) fileInputRef.current.value = ''
    }

    video.onloadedmetadata = handleMetadata
    video.onerror = handleError
    video.src = url
  }

  const handleUpload = async () => {
    if (!file) return

    setUploading(true)
    setError(null)
    setUploadStatus('Uploading video...')

    try {
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        const UPLOAD_TIMEOUT_MS = 120000 // 2 minutes timeout
        
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 100)
            setUploadStatus(`Uploading video... ${percent}%`)
          }
        }

        xhr.onload = async () => {
          try {
            if (xhr.status < 200 || xhr.status >= 300) {
              let message = `Upload failed (HTTP ${xhr.status})`

              try {
                const data = JSON.parse(xhr.responseText)
                message = data.error || message
              } catch {
                // Keep the useful HTTP status when the body isn't JSON
              }

              throw new Error(message)
            }

            // Upload succeeded
            setUploadStatus('Video uploaded')

            // Cleanup
            setFile(null)
            setPreview(null)
            if (previewUrl) {
              URL.revokeObjectURL(previewUrl)
              setPreviewUrl(null)
            }
            setDuration(null)
            await loadExistingClip()
            onUploadComplete?.()
            resolve()
          } catch (error) {
            reject(
              error instanceof Error
                ? error
                : new Error('Upload failed')
            )
          }
        }

        xhr.onerror = () => {
          setError('Network error during upload')
          setUploadStatus(null)
          reject(new Error('Network error'))
        }

        xhr.onabort = () => {
          setError('Upload cancelled')
          setUploadStatus(null)
          reject(new Error('Upload cancelled'))
        }

        xhr.ontimeout = () => {
          setError('Upload timed out')
          setUploadStatus(null)
          reject(new Error('Upload timed out'))
        }

        xhr.timeout = UPLOAD_TIMEOUT_MS
        xhr.open('POST', `/api/sim/videos?device=${device}`)
        xhr.send(file)
      })
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Upload failed')
      setUploadStatus(null)
    } finally {
      setUploading(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm('Delete this video?')) return

    setError(null)
    setUploadStatus('Deleting...')

    try {
      const response = await fetch(`/api/sim/videos?device=${device}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        const data = await response.json().catch(() => ({}))
        throw new Error(data.error || 'Delete failed')
      }

      setUploadedClip(null)
      setUploadStatus('Video deleted')
      onUploadComplete?.()
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to delete video')
      setUploadStatus(null)
    }
  }

  const handleCancel = () => {
    setFile(null)
    setPreview(null)
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl)
      setPreviewUrl(null)
    }
    setDuration(null)
    setError(null)
    setUploadStatus(null)
    // Reset file input
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <input
          ref={fileInputRef}
          type="file"
          accept="video/mp4"
          onChange={handleFileSelect}
          disabled={uploading}
          className="text-xs text-slate-400"
        />
        {file && (
          <>
            <button
              onClick={handleUpload}
              disabled={uploading || !!error}
              className="rounded-lg bg-cyan-600 px-3 py-1 text-xs font-semibold hover:bg-cyan-500 disabled:opacity-40"
            >
              {uploading ? uploadStatus : 'Upload'}
            </button>
            <button
              onClick={handleCancel}
              disabled={uploading}
              className="rounded-lg bg-slate-600 px-3 py-1 text-xs hover:bg-slate-500 disabled:opacity-40"
            >
              Cancel
            </button>
          </>
        )}
        {!file && uploadedClip && (
          <button
            onClick={handleDelete}
            disabled={uploading}
            className="rounded-lg bg-red-700 px-3 py-1 text-xs hover:bg-red-600 disabled:opacity-40"
          >
            Delete
          </button>
        )}
      </div>

      {loadingClip && (
        <p className="text-xs text-slate-500">Loading clip status...</p>
      )}

      {!loadingClip && !uploadedClip && !file && (
        <p className="text-xs text-slate-500">No clip uploaded for this device</p>
      )}

      {!loadingClip && uploadedClip && !file && (
        <div className="mt-2 p-2 bg-slate-800 rounded-lg">
          <p className="text-xs text-slate-300">
            Uploaded clip ({(uploadedClip.size / (1024 * 1024)).toFixed(2)} MB)
          </p>
          <video
            src={`/api/sim/videos/${device}`}
            controls
            className="w-full rounded-lg bg-black mt-2"
            style={{ maxHeight: '200px' }}
          />
        </div>
      )}

      {preview && (
        <div className="mt-2">
          <video
            ref={videoRef}
            src={preview}
            controls
            className="w-full rounded-lg bg-black"
            style={{ maxHeight: '200px' }}
          />
          <p className="mt-1 text-xs text-slate-400">
            {file?.name} ({((file?.size ?? 0) / (1024 * 1024)).toFixed(2)} MB)
            {duration !== null && ` · ${duration.toFixed(1)}s`}
          </p>
        </div>
      )}

      {error && (
        <p className="text-xs text-red-400">{error}</p>
      )}

      {uploadStatus && !error && (
        <p className="text-xs text-emerald-400">{uploadStatus}</p>
      )}

      <p className="text-xs text-slate-500">
        Max {MAX_SIZE_MB} MB, {MAX_DURATION_SEC} seconds. MP4 only.
      </p>
    </div>
  )
}
