'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useDoorbell } from '../hooks/useDoorbell'
import type { Answer, Visitor, ExpectedVisit } from '@/lib/doorbell/store'
import EnableAlerts from './EnableAlerts'
import ExpectedForm from './ExpectedForm'
import LiveView from './LiveView'
import VisitRequests from './VisitRequests'
import RegularVisitors from './RegularVisitors'
import InterrogationCard from './InterrogationCard'
import LifecyclePanel from './LifecyclePanel'
import NoteComposer from './NoteComposer'
import { auditRows } from '@/lib/doorstep/auditView'

export default function HelperPage() {
  const { snap, stale, unauthorized, refresh, secondsLeft } = useDoorbell()
  const [err, setErr] = useState('')
  const [visitor, setVisitor] = useState<Visitor | null>(null)
  const [, force] = useState(0)

  useEffect(() => {
    const t = setInterval(() => force((n) => n + 1), 1000)
    return () => clearInterval(t)
  }, [])

  const caseId = snap?.current?.id
  useEffect(() => setVisitor(null), [caseId])

  if (unauthorized) {
    return <main className="p-6 text-center text-amber-300">You are not signed in. Open your personal link again, or ask the guardian for a new one.</main>
  }
  if (!snap) return <main className="p-6 text-slate-400">Loading…</main>

  const me = snap?.me ?? ''
  const helper = snap.helpers.find((h) => h.id === me)
  const c = snap.current
  const idx = c ? c.chain.indexOf(me) : -1
  const visible = !!c && idx >= 0 && (c.kind === 'sos' || c.helperIndex >= idx || c.status !== 'waiting')
  const myTurn = !!c && c.status === 'waiting' && idx >= 0 && (c.kind === 'sos' || c.helperIndex === idx)

  const answer = async (a: Answer, who?: Visitor) => {
    if (!c) return
    setErr('')
    const r = await fetch('/api/doorbell/answer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ caseId: c.id, answer: a, visitor: who ?? visitor ?? undefined }),
    })
    if (r.ok === false) setErr((await r.json().catch(() => ({}))).error || 'Could not send your answer. Try again or call the resident.')
    refresh()
  }
  const ack = async () => {
    if (!c) return
    await fetch('/api/doorbell/ack', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ caseId: c.id }) })
    refresh()
  }

  // Section 7: Accept/decline helper request
  const acceptRequest = async (accept: boolean, requestId?: string) => {
    if (!c) return
    setErr('')
    const r = await fetch('/api/doorbell/accept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ caseId: c.id, membershipId: me, accept, requestId }),
    })
    if (r.ok === false) setErr((await r.json().catch(() => ({}))).error || 'Could not send your response. Try again.')
    refresh()
  }

  // Section 7.4: take over or release the conversation. While a helper owns it, the AI stays silent.
  const takeover = async (action: 'takeover' | 'release') => {
    if (!c) return
    setErr('')
    const r = await fetch('/api/doorbell/takeover', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ caseId: c.id, action }),
    })
    if (r.ok === false) setErr((await r.json().catch(() => ({}))).error || 'Could not change who owns the conversation.')
    refresh()
  }

  // Section 7: Approve/reject pending action
  const decideAction = async (actionId: string, decision: 'approve' | 'reject', reason?: string) => {
    if (!c) return
    setErr('')
    const r = await fetch('/api/doorbell/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ caseId: c.id, actionId: actionId, decision: decision, reason: reason }),
    })
    if (r.ok === false) setErr((await r.json().catch(() => ({}))).error || 'Could not record your decision. Try again.')
    refresh()
  }

  // Section 7: Escalate to next helper
  const escalate = async () => {
    if (!c) return
    setErr('')
    const r = await fetch('/api/doorbell/escalate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ caseId: c.id }),
    })
    if (r.ok === false) setErr((await r.json().catch(() => ({}))).error || 'Could not escalate. Try again.')
    refresh()
  }

  const canSafe = visitor === 'known' || visitor === 'delivery'
  const Buttons = (
    <div className="mt-4">
      <p className="mb-2 text-sm text-slate-300">Who is it?</p>
      <div className="mb-4 grid grid-cols-3 gap-2">
        {([['known', '👤 Known'], ['delivery', '📦 Delivery'], ['unknown', '❓ Unknown']] as const).map(([v, t]) => (
          <button
            key={v}
            onClick={() => setVisitor(v)}
            className={`rounded-xl py-3 font-semibold ${visitor === v ? 'bg-cyan-500 text-black' : 'bg-slate-700'} ${v === 'known' && c?.regularId && visitor !== 'known' ? 'ring-2 ring-emerald-400' : ''}`}
          >
            {t}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-3 gap-3">
        <button disabled={!canSafe} onClick={() => answer('safe')} className="rounded-2xl bg-emerald-600 py-5 text-lg font-bold disabled:opacity-30">✅ Open door</button>
        <button onClick={() => answer('not_safe')} className="rounded-2xl bg-red-600 py-5 text-lg font-bold">⛔ Don't open</button>
        <button onClick={() => answer('call_me')} className="rounded-2xl bg-indigo-600 py-5 text-lg font-bold">📞 I'll call</button>
      </div>
    </div>
  )
  const ExpectedButtons = (
    <div className="mt-4">
      <div className="grid grid-cols-3 gap-3">
        <button onClick={() => { setVisitor('known'); void answer('safe', 'known') }} className="rounded-2xl bg-emerald-600 py-5 text-lg font-bold">✅ Confirm identity</button>
        <button onClick={() => answer('not_safe')} className="rounded-2xl bg-red-600 py-5 text-lg font-bold">⛔ Not them</button>
        <button onClick={() => answer('call_me')} className="rounded-2xl bg-indigo-600 py-5 text-lg font-bold">📞 I'll call</button>
      </div>
      <p className="mt-2 text-xs text-slate-400">If you do nothing, it becomes a normal visitor alert after a short wait.</p>
    </div>
  )

  return (
    <main className="min-h-screen bg-slate-900 text-white p-4 max-w-2xl mx-auto" aria-live="polite">
      <header className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold">Helper: {helper?.emoji} {helper?.name ?? 'choose a helper'}</h1>
      </header>
      <div className="flex items-center justify-between mb-4">
        <EnableAlerts />
        <Link href="/setup" className="text-sm text-cyan-400">⚙️ Setup</Link>
      </div>
      {stale && <p role="alert" className="mb-4 rounded-xl bg-amber-700 p-3 text-center font-semibold">Connection lost. What you see may be out of date.</p>}
      {snap.alerts?.degraded && (
        <p role="alert" className="mb-4 rounded-xl bg-amber-700 p-3 text-center font-semibold">
          {snap.alerts.helpersWithoutPush.length > 0
            ? `Alerts are off for: ${snap.alerts.helpersWithoutPush.join(', ')}. They will not hear the doorbell. Turn alerts on.`
            : 'Some alerts failed to send. If you are unsure, call the resident.'}
        </p>
      )}
      {err && <p role="alert" className="mb-4 rounded-xl bg-red-900 p-3 text-center">{err}</p>}
      <a href="/helper/history" className="mb-4 inline-block text-sm text-cyan-400">📋 History</a>

      {!c || !visible ? (
        <div className="rounded-2xl bg-slate-800 p-10 text-center">
          <div className="text-6xl mb-3">😌</div>
          <p className="text-lg">Nothing needs you right now.</p>
          {c && c.status === 'waiting' && (
            <p className="text-sm text-slate-400 mt-2">
              {snap.helpers.find((h) => h.id === c.chain[c.helperIndex])?.name} has been asked. It reaches you if they do not answer.
            </p>
          )}
        </div>
      ) : (
        <div className={`rounded-2xl p-4 ${c.kind === 'sos' ? 'bg-rose-900' : c.lane === 'expected' ? 'bg-sky-900' : 'bg-slate-800'}`}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold">
              {c.kind === 'sos' ? '🆘 Resident pressed "I need help"'
                : c.lane === 'expected' ? `${c.visitIcon} ${c.visitLabel} may be at the door`
                : '🚪 Someone is at the door'}
            </h2>
            {c.status === 'waiting' && (
              <span className="px-3 py-1 rounded-full bg-black/30 text-sm">{secondsLeft(c.deadlineAt)}s left</span>
            )}
          </div>

          {/* Section 7.9: show live view whenever a doorbell device exists, and be honest when none is available. */}
          {c.deviceId ? (
            <LiveView caseId={c.id} deviceId={c.deviceId} />
          ) : (
            <div className="rounded-xl bg-slate-700 aspect-video flex items-center justify-center text-slate-300 text-sm text-center px-6">
              No doorbell camera is linked to this case, so there is no live video or audio to show. Do not assume the door is clear.
            </div>
          )}

          {/* Section 7.4: who owns the conversation, with Take over / Release */}
          {c.status === 'waiting' && (
            <div className="mt-3 rounded-xl bg-slate-700 p-3 text-sm">
              {(c as any).conversationOwner ? (
                <div className="flex items-center justify-between gap-2">
                  <span>🎙️ {(c as any).conversationOwner === me ? 'You' : (snap.helpers.find((h) => h.id === (c as any).conversationOwner)?.name ?? 'A helper')} {(c as any).conversationOwner === me ? 'are' : 'is'} speaking. The AI is silent.</span>
                  {(c as any).conversationOwner === me && (
                    <button onClick={() => takeover('release')} className="rounded-lg bg-slate-500 px-3 py-1.5 font-semibold">Release</button>
                  )}
                </div>
              ) : (
                <div className="flex items-center justify-between gap-2">
                  <span>The AI is handling the conversation.</span>
                  <button onClick={() => takeover('takeover')} className="rounded-lg bg-amber-600 px-3 py-1.5 font-semibold">Take over</button>
                </div>
              )}
            </div>
          )}

          {c.status === 'waiting' && !c.ackedAt && (c.kind === 'sos' || snap.helpers.some(h => h.id === me)) && (
            <button onClick={ack} className="mt-3 w-full rounded-2xl bg-white py-4 text-lg font-bold text-rose-900">👀 I have seen this. I am on it.</button>
          )}
          {c.ackedAt && <p className="mt-3 text-sm text-emerald-300">Seen by {snap.helpers.find((h) => h.id === c.ackedBy)?.name}.</p>}

          {/* Section 7: Helper request display */}
          {(c as any).helperRequests && (c as any).helperRequests.length > 0 && (
            <div className="mt-4 rounded-xl bg-slate-700 p-3">
              <h3 className="text-sm font-semibold mb-2">📬 Helper Requests</h3>
              {(c as any).helperRequests.map((req: any) => (
                <div key={req.id} className="mb-2 text-sm border-b border-slate-600 pb-2 last:border-0">
                  <div className="flex justify-between items-center">
                    <span className="font-medium capitalize">{req.kind.replace('_', ' ')}</span>
                    <span className={`px-2 py-0.5 rounded text-xs ${
                      req.state === 'sent' ? 'bg-amber-600' :
                      req.state === 'delivered' ? 'bg-blue-600' :
                      req.state === 'acked' ? 'bg-purple-600' :
                      req.state === 'accepted' ? 'bg-emerald-600' :
                      req.state === 'declined' ? 'bg-red-600' :
                      req.state === 'timed_out' ? 'bg-slate-600' : 'bg-slate-500'
                    }`}>{req.state}</span>
                  </div>
                  {req.membershipId === me && ['sent', 'delivered', 'acked'].includes(req.state) && req.kind !== 'emergency' && (
                    <div className="mt-2">
                      <p className="text-xs text-slate-300 mb-1">
                        {req.kind === 'approval' ? 'The AI needs your approval. Review the exact action below.'
                          : req.kind === 'takeover' ? 'The risk is high. Please take responsibility for this case.'
                          : 'A helper decision is needed on this case.'}
                      </p>
                      <div className="flex gap-2">
                        <button onClick={() => acceptRequest(true, req.id)} className="flex-1 rounded-lg bg-emerald-600 py-2 text-sm font-semibold">{req.kind === 'approval' ? 'Accept' : 'I will handle this'}</button>
                        <button onClick={() => acceptRequest(false, req.id)} className="flex-1 rounded-lg bg-red-600 py-2 text-sm font-semibold">Decline</button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Section 7: Pending actions display */}
          {(c as any).pendingActions && (c as any).pendingActions.length > 0 && (
            <div className="mt-4 rounded-xl bg-slate-700 p-3">
              <h3 className="text-sm font-semibold mb-2">⚡ Pending Actions</h3>
              {(c as any).pendingActions.map((action: any) => (
                <div key={action.id} className="mb-2 text-sm border-b border-slate-600 pb-2 last:border-0">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{action.kind === 'visit_approval' ? 'Short-notice visit' : action.tool}</span>
                    <span className={`px-2 py-0.5 rounded text-xs ${
                      action.state === 'pending' ? 'bg-amber-600' :
                      action.state === 'approved' ? 'bg-emerald-600' :
                      action.state === 'rejected' ? 'bg-red-600' :
                      action.state === 'consumed' ? 'bg-slate-600' : 'bg-slate-500'
                    }`}>{action.state}</span>
                  </div>
                  {action.text && action.text !== action.tool && (
                    <p className="mt-1 rounded bg-slate-800 p-2 text-sm">"{action.text}"</p>
                  )}
                  {action.reason && <p className="mt-1 text-xs text-slate-400">Why it needs approval: {action.reason.replace(/_/g, ' ')}</p>}
                  {action.state === 'approved' && (
                    <p className="mt-1 text-xs text-slate-300">Approved{action.decidedBy === me ? ' by you' : ''}. {action.kind === 'visit_approval' ? 'The visit may proceed.' : 'The AI will use it once.'}</p>
                  )}
                  {action.state === 'pending' && action.approver === 'resident' && (
                    <p className="mt-2 text-xs text-slate-300">Waiting for the resident to decide.</p>
                  )}
                  {action.state === 'pending' && action.approver !== 'resident' && (
                    <div className="mt-2">
                      <p className="text-xs text-slate-300 mb-1">Approving lets this happen once. Silence is never approval.</p>
                      <div className="flex gap-2">
                        <button onClick={() => decideAction(action.id, 'approve')} className="flex-1 rounded-lg bg-emerald-600 py-2 text-sm font-semibold">Approve</button>
                        <button onClick={() => decideAction(action.id, 'reject')} className="flex-1 rounded-lg bg-red-600 py-2 text-sm font-semibold">Reject</button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Section 7: Escalate button */}
          {c.status === 'waiting' && myTurn && idx < c.chain.length - 1 && (
            <button onClick={escalate} className="mt-3 w-full rounded-xl bg-amber-600 py-2 text-sm font-semibold">
              ⬆️ Escalate to next helper
            </button>
          )}

          {c.regularId && c.lane !== 'expected' && (
            <p className="mb-3 rounded-xl bg-emerald-900 p-3 text-sm">
              {c.visitIcon ?? '🙂'} Door camera: looks like regular visitor <b>{c.visitLabel}</b>. Check the person before you answer.
            </p>
          )}

          <LifecyclePanel c={c} info={snap.lifecycleInfo} onChanged={refresh} />

          {c.kind === 'visitor' && c.lane !== 'expected' && <InterrogationCard caseId={c.id} />}

          {(snap.expectedNow.length > 0 || snap.recurringNow.length > 0) && (
            <p className="mb-2 text-sm text-amber-300">Expected now: {[...snap.expectedNow, ...snap.recurringNow].map((e) => `${e.icon} ${e.label}`).join(', ')}</p>
          )}

          {c.status === 'waiting' && myTurn && (c.lane === 'expected' ? ExpectedButtons : Buttons)}
          {c.status === 'answered' && (
            <p className="mt-4 text-emerald-300">
              Answered: {c.answer === 'safe' ? 'Open door' : c.answer === 'not_safe' ? 'Don\'t open' : 'Will call'} by{' '}
              {snap.helpers.find((h) => h.id === c.answeredBy)?.name}.
            </p>
          )}
          {c.status === 'no_response' && (
            <div className="mt-4">
              <p className="text-amber-300 mb-3">Nobody answered. Resident was told to keep the door closed. You can still answer:</p>
              {Buttons}
            </div>
          )}
        </div>
      )}

      <VisitRequests requireResidentOk={!!(snap as any).requireResidentOk} />
      <NoteComposer />
      <RegularVisitors />
      <ExpectedForm items={snap.expected} onChange={refresh} />

      <section className="mt-6">
        <h3 className="text-sm uppercase tracking-wide text-slate-400 mb-2">Latest case timeline and audit</h3>
        <ul className="text-sm space-y-1 text-slate-300">
          {(snap.history[0]?.log ?? []).map((l: any, i) => (
            <li key={i}>
              <span className="text-slate-500">{new Date(l.t).toLocaleTimeString()}</span> {l.msg}
              {l.audit && (
                <span className="block ml-4 text-xs text-slate-400">
                  {l.audit.actor}{l.audit.actorId ? ` (${String(l.audit.actorId).slice(0, 8)})` : ''} · {l.audit.kind}
                  {l.audit.ref ? ` · ref ${l.audit.ref}` : ''}
                  {l.audit.detail ? ` · ${JSON.stringify(l.audit.detail)}` : ''}
                </span>
              )}
            </li>
          ))}
          {snap.history.length === 0 && <li className="text-slate-500">No events yet.</li>}
        </ul>
      </section>
    </main>
  )
}
