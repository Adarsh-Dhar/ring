/**
 * Collaboration controller (spec sections 1, 2 and 5): who leads, how much the AI may do, and the timers.
 *
 * Pure, no imports apart from the other doorstep modules. Every score value gets its own autonomy budget,
 * oversight index, helper priority and timers (no hidden buckets). Permitted actions change only at the mode edges.
 *
 * Section 5: every value comes from the EFFECTIVE score S_eff = max(S, floor score of the event minimum mode).
 */
import { CONTROL_MODES, maxMode, modeRank, type ControlMode } from './riskRules'
import { permittedActions, type Permissions, type Preferences } from './residentPreferences'
import { AUTHORITY_COST } from './authorityCosts'
import { MODE_LABEL } from './modeCopy'

/** Score at which the control mode rises by itself (before any event floor). Pilot starting values.
 * Step 6 (Option A): emergency is now reserved for score 100 (forced entry / SOS / confirmed assault).
 * Score 80–99 maps to helper_urgent, matching the immediate_threat floor. */
export const MODE_THRESHOLDS: { atLeast: number; mode: ControlMode }[] = [
  { atLeast: 100, mode: 'emergency' },
  { atLeast: 80,  mode: 'helper_urgent' },
  { atLeast: 60,  mode: 'helper_only' },
  { atLeast: 40,  mode: 'helper_leads' },
  { atLeast: 20,  mode: 'ai_assisted' },
  { atLeast: 0,   mode: 'ai_leads' },
]

export function modeForScore(score: number): ControlMode {
  const s = Math.max(0, Math.min(100, Math.round(score)))
  return MODE_THRESHOLDS.find(t => s >= t.atLeast)!.mode
}

/** Lowest score of each mode: the floor score a minimum mode contributes to S_eff (spec 5, first paragraph).
 * Derived from MODE_THRESHOLDS so there is one source of truth. Confirm the helper-led value against section 6.3. */
export const MODE_FLOOR_SCORE = Object.fromEntries(MODE_THRESHOLDS.map(t => [t.mode, t.atLeast])) as Record<ControlMode, number>

/** Spec 6.1: the effective mode is the more human-led of the event minimum and the band of the confirmed score S.
 *  The stored case.controlMode holds only the event minimum, so anything that shows or enforces a mode must use this. */
export function effectiveModeFor(score: number | null | undefined, minMode?: ControlMode | null): ControlMode {
  return maxMode(modeForScore(effectiveScore(score ?? 0, minMode)), minMode ?? 'ai_leads')
}

const clampScore = (n: number) => Math.max(0, Math.min(100, Math.round(Number.isFinite(n) ? n : 0)))

/** S_eff = max(S, event floor). With no serious event active the floor is 0, so S_eff = S. */
export function effectiveScore(score: number, minMode?: ControlMode | null): number {
  return Math.max(clampScore(score), MODE_FLOOR_SCORE[minMode ?? 'ai_leads'])
}

/** Spec 5.3. Pilot defaults, not validated. */
export const DEFAULT_APPROVAL_SECONDS = 120
export const RISK_TIMER_BASE = 120
export const TAKEOVER_CAP_SECONDS = 60

export interface Timers {
  /** A resident rule needs helper approval (any score, including 0). Set by the resident. */
  approvalSec: number
  /** 120 - S_eff for 1 <= S_eff <= 99, otherwise null (0 is not risk-driven, 100 is an emergency). */
  riskDecisionSec: number | null
  /** min(120 - S_eff, 60) when helper-led (S_eff >= 60 or an event minimum of helper-led), otherwise null. */
  takeoverSec: number | null
  /** Emergency has no timer: primary and backup are alerted together. */
  emergency: null
  /** Which timer is governing the deadline (if known) */
  kind?: 'household' | 'approval' | 'risk_decision' | 'takeover'
}

export function timersFor(sEff: number, minMode?: ControlMode | null, approvalSec?: number): Timers {
  const s = clampScore(sEff)
  const helperLed = s >= 60 || modeRank(minMode ?? 'ai_leads') >= modeRank('helper_only')
  const riskDecisionSec = s >= 1 && s <= 99 ? RISK_TIMER_BASE - s : null
  const takeoverSec = helperLed && s < 100 ? Math.min(RISK_TIMER_BASE - s, TAKEOVER_CAP_SECONDS) : null
  const approvalSecVal = Number.isFinite(approvalSec) && approvalSec && approvalSec > 0 ? Math.round(approvalSec) : DEFAULT_APPROVAL_SECONDS
  
  // Determine which timer kind is governing (shortest non-null wins)
  // Tie-breaking: takeover > risk_decision > approval when equal (more urgent takes precedence)
  let kind: 'household' | 'approval' | 'risk_decision' | 'takeover' | undefined
  const seconds = [approvalSecVal, riskDecisionSec, takeoverSec].filter((x): x is number => x !== null)
  if (seconds.length > 0) {
    const min = Math.min(...seconds)
    // Check takeover first (most urgent)
    if (takeoverSec !== null && takeoverSec === min) kind = 'takeover'
    // Then risk-decision
    else if (riskDecisionSec !== null && riskDecisionSec === min) kind = 'risk_decision'
    // Finally approval
    else if (approvalSecVal === min) kind = 'approval'
  }
  
  return {
    approvalSec: approvalSecVal,
    riskDecisionSec,
    takeoverSec,
    emergency: null,
    kind,
  }
}

export type TimerKind = 'approval' | 'risk_decision' | 'takeover' | 'emergency'

/** Which timer governs now. When several apply, the shortest wins (a person is needed for more than one reason). */
export function activeTimer(
  t: Timers,
  ctx: { needsApproval?: boolean; riskDecisionNeeded?: boolean; emergency?: boolean } = {},
): { kind: TimerKind; seconds: number | null } | null {
  if (ctx.emergency) return { kind: 'emergency', seconds: null }
  const c: { kind: TimerKind; seconds: number }[] = []
  if (ctx.needsApproval) c.push({ kind: 'approval', seconds: t.approvalSec })
  if (t.takeoverSec !== null) c.push({ kind: 'takeover', seconds: t.takeoverSec })
  if (ctx.riskDecisionNeeded && t.riskDecisionSec !== null) c.push({ kind: 'risk_decision', seconds: t.riskDecisionSec })
  if (c.length === 0) return null
  return c.reduce((a, b) => (b.seconds < a.seconds ? b : a))
}

/** Spec 5.3: a helper decision is needed because of the score once the cheapest routine action no longer fits the budget.
 *  greet_routine_request costs 81, so this is true from S_eff 20. Below that the AI handles the visit alone. */
export function riskDecisionNeeded(sEff: number): boolean {
  return AUTHORITY_COST.greet_routine_request > 100 - clampScore(sEff)
}

/** Dashboard order (spec 5.2): S_eff, then event severity, then the most recent event first. */
export function compareForDashboard(
  a: { effectiveScore: number; eventSeverity: number; lastEventAt: number },
  b: { effectiveScore: number; eventSeverity: number; lastEventAt: number },
): number {
  return b.effectiveScore - a.effectiveScore || b.eventSeverity - a.eventSeverity || b.lastEventAt - a.lastEventAt
}

export interface Control {
  /** S_eff, the effective score. Every value below comes from it. */
  score: number
  effectiveScore: number
  /** The confirmed behaviour score S before any event floor. */
  rawScore: number
  mode: ControlMode
  /** Mode label (M0 to M5) for display. */
  modeLabel: string
  /** Severity of the event-set minimum mode (0 = none). Second key of the dashboard order. */
  eventSeverity: number
  /** 100 minus S_eff: how much room the AI has to act alone. */
  aiAutonomyBudget: number
  /** Equal to S_eff: how closely a person should watch. */
  humanOversightIndex: number
  /** Dashboard rank. Higher means look at this case first: S_eff, then event severity. */
  helperPriority: number
  timers: Timers
  permissions: Permissions
  /** Plain sentence for the case log and the helper screen. */
  summary: string
}

const LEADS: Record<ControlMode, string> = {
  ai_leads: 'The assistant leads. The helper can see everything.',
  ai_assisted: 'The assistant leads with the helper watching.',
  helper_leads: 'The helper leads. The assistant only helps and reports.',
  helper_only: 'The helper is in charge. The assistant stays quiet unless asked.',
  helper_urgent: 'Urgent. The helper is in charge. The assistant stays quiet unless asked.',
  emergency: 'Emergency. The helper and emergency contacts are being alerted.',
}

export function computeControl(input: { score: number; minMode?: ControlMode | null; prefs: Preferences; approvalSec?: number }): Control {
  const rawScore = clampScore(input.score)
  const sEff = effectiveScore(rawScore, input.minMode)
  // Events outrank the score: the mode is never lower than the floor an event set.
  const mode = maxMode(modeForScore(sEff), input.minMode ?? 'ai_leads')
  const eventSeverity = modeRank(input.minMode ?? 'ai_leads')
  return {
    score: sEff, effectiveScore: sEff, rawScore, mode, modeLabel: MODE_LABEL[mode] ?? 'M0', eventSeverity,
    aiAutonomyBudget: 100 - sEff,
    humanOversightIndex: sEff,
    helperPriority: sEff * 10 + eventSeverity,
    timers: timersFor(sEff, input.minMode, input.approvalSec),
    permissions: permittedActions(input.prefs, mode, sEff),
    summary: LEADS[mode],
  }
}
